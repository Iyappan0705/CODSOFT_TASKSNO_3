const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const pool = require("../db");
const { auth, role } = require("../middleware/auth");

const router = express.Router();

const uploadDir = path.join(__dirname, "..", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${req.user.id}-${Date.now()}-${safe}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    const allowed = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ];
    cb(null, allowed.includes(file.mimetype));
  }
});

router.post(
  "/",
  auth,
  role("candidate"),
  upload.single("resume"),
  async (req, res) => {
    try {
      const { jobId, coverLetter = "" } = req.body;

      if (!jobId) {
        return res.status(400).json({ message: "Job is required" });
      }

      const job = await pool.query("SELECT id FROM jobs WHERE id = $1", [jobId]);
      if (!job.rows.length) {
        return res.status(404).json({ message: "Job not found" });
      }

      const existing = await pool.query(
        "SELECT id FROM applications WHERE job_id = $1 AND candidate_id = $2",
        [jobId, req.user.id]
      );

      if (existing.rows.length) {
        return res.status(409).json({ message: "You already applied for this job" });
      }

      const resumePath = req.file ? `/uploads/${req.file.filename}` : null;

      const result = await pool.query(
        `INSERT INTO applications
         (job_id, candidate_id, resume_path, cover_letter)
         VALUES ($1,$2,$3,$4)
         RETURNING *`,
        [jobId, req.user.id, resumePath, coverLetter]
      );

      res.status(201).json({
        message: "Application submitted",
        application: result.rows[0]
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Could not submit application" });
    }
  }
);

router.get("/mine", auth, role("candidate"), async (req, res) => {
  const result = await pool.query(
    `SELECT a.*, j.title, j.company, j.location
     FROM applications a
     JOIN jobs j ON j.id = a.job_id
     WHERE a.candidate_id = $1
     ORDER BY a.applied_at DESC`,
    [req.user.id]
  );
  res.json(result.rows);
});

router.get("/recruiter", auth, role("recruiter"), async (req, res) => {
  const result = await pool.query(
    `SELECT a.*, j.title, j.company,
            u.name AS candidate_name, u.email AS candidate_email
     FROM applications a
     JOIN jobs j ON j.id = a.job_id
     JOIN users u ON u.id = a.candidate_id
     WHERE j.recruiter_id = $1
     ORDER BY a.applied_at DESC`,
    [req.user.id]
  );
  res.json(result.rows);
});

router.patch("/:id/status", auth, role("recruiter"), async (req, res) => {
  const { status } = req.body;
  const allowed = ["Applied", "Shortlisted", "Rejected", "Selected"];

  if (!allowed.includes(status)) {
    return res.status(400).json({ message: "Invalid status" });
  }

  const result = await pool.query(
    `UPDATE applications a
     SET status = $1
     FROM jobs j
     WHERE a.id = $2
       AND a.job_id = j.id
       AND j.recruiter_id = $3
     RETURNING a.*`,
    [status, req.params.id, req.user.id]
  );

  if (!result.rows.length) {
    return res.status(404).json({ message: "Application not found" });
  }

  res.json(result.rows[0]);
});

module.exports = router;
