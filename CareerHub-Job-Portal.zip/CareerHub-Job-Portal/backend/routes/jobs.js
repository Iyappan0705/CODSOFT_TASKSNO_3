const express = require("express");
const pool = require("../db");
const { auth, role } = require("../middleware/auth");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const { search = "", location = "" } = req.query;

    const result = await pool.query(
      `SELECT j.*, u.name AS recruiter_name
       FROM jobs j
       JOIN users u ON u.id = j.recruiter_id
       WHERE (LOWER(j.title) LIKE LOWER($1)
          OR LOWER(j.company) LIKE LOWER($1)
          OR LOWER(j.skills) LIKE LOWER($1))
         AND LOWER(j.location) LIKE LOWER($2)
       ORDER BY j.created_at DESC`,
      [`%${search}%`, `%${location}%`]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not load jobs" });
  }
});

router.post("/", auth, role("recruiter"), async (req, res) => {
  try {
    const {
      title, company, location, jobType, description, skills, salary
    } = req.body;

    if (!title || !company || !location || !jobType || !description || !skills) {
      return res.status(400).json({ message: "Fill all required job fields" });
    }

    const result = await pool.query(
      `INSERT INTO jobs
       (recruiter_id, title, company, location, job_type, description, skills, salary)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [
        req.user.id, title, company, location, jobType,
        description, skills, salary || null
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not create job" });
  }
});

router.get("/mine", auth, role("recruiter"), async (req, res) => {
  const result = await pool.query(
    "SELECT * FROM jobs WHERE recruiter_id = $1 ORDER BY created_at DESC",
    [req.user.id]
  );
  res.json(result.rows);
});

module.exports = router;
