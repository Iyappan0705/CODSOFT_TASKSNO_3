"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

export default function PostJob() {
  const router = useRouter();
  const [form, setForm] = useState({
    title: "", company: "", location: "", jobType: "Full-time",
    description: "", skills: "", salary: ""
  });
  const [message, setMessage] = useState("");

  async function submit(e) {
    e.preventDefault();
    const token = localStorage.getItem("token");

    if (!token) {
      router.push("/login");
      return;
    }

    const res = await fetch(`${API}/jobs`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(form)
    });

    const data = await res.json();

    if (!res.ok) {
      setMessage(data.message || "Could not create job");
      return;
    }

    setMessage("Job posted successfully");
    setTimeout(() => router.push("/"), 700);
  }

  return (
    <main className="authPage">
      <form className="form card wide" onSubmit={submit}>
        <h1>Post a Job</h1>
        {Object.entries({
          title: "Job title",
          company: "Company",
          location: "Location",
          skills: "Skills (e.g. React, Node.js)",
          salary: "Salary"
        }).map(([key, placeholder]) => (
          <input
            key={key}
            placeholder={placeholder}
            value={form[key]}
            required={key !== "salary"}
            onChange={e => setForm({ ...form, [key]: e.target.value })}
          />
        ))}

        <select
          value={form.jobType}
          onChange={e => setForm({ ...form, jobType: e.target.value })}
        >
          <option>Full-time</option>
          <option>Part-time</option>
          <option>Internship</option>
          <option>Contract</option>
        </select>

        <textarea
          placeholder="Job description"
          rows={7}
          required
          value={form.description}
          onChange={e => setForm({ ...form, description: e.target.value })}
        />

        <button className="button">Publish Job</button>
        <p>{message}</p>
        <Link href="/dashboard">Back to dashboard</Link>
      </form>
    </main>
  );
}
