"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

export default function Home() {
  const [jobs, setJobs] = useState([]);
  const [search, setSearch] = useState("");

  async function loadJobs() {
    const res = await fetch(`${API}/jobs?search=${encodeURIComponent(search)}`);
    const data = await res.json();
    setJobs(Array.isArray(data) ? data : []);
  }

  useEffect(() => { loadJobs(); }, []);

  return (
    <main>
      <nav className="nav">
        <Link href="/" className="brand">CareerHub</Link>
        <div>
          <Link href="/login" className="navLink">Login</Link>
          <Link href="/register" className="button small">Register</Link>
        </div>
      </nav>

      <section className="hero">
        <p className="eyebrow">JOB PORTAL</p>
        <h1>Find your next opportunity.</h1>
        <p>Search jobs, apply online and track your applications.</p>

        <div className="searchBox">
          <input
            placeholder="Search title, company or skill"
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === "Enter" && loadJobs()}
          />
          <button onClick={loadJobs}>Search</button>
        </div>
      </section>

      <section className="container">
        <h2>Latest Jobs</h2>
        <div className="grid">
          {jobs.map(job => (
            <article className="card" key={job.id}>
              <h3>{job.title}</h3>
              <p><b>{job.company}</b> · {job.location}</p>
              <p>{job.job_type} {job.salary ? `· ${job.salary}` : ""}</p>
              <p className="muted">{job.description}</p>
              <Link href="/login" className="button">Login to Apply</Link>
            </article>
          ))}
        </div>
        {!jobs.length && <p>No jobs found.</p>}
      </section>
    </main>
  );
}
