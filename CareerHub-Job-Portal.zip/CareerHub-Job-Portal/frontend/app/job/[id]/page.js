"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

export default function JobDetails() {
  const params = useParams();
  const [job, setJob] = useState(null);
  const [letter, setLetter] = useState("");
  const [resume, setResume] = useState(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch(`${API}/jobs`)
      .then(r => r.json())
      .then(data => setJob(data.find(x => String(x.id) === String(params.id))));
  }, [params.id]);

  async function apply(e) {
    e.preventDefault();

    const token = localStorage.getItem("token");
    if (!token) {
      window.location.href = "/login";
      return;
    }

    const fd = new FormData();
    fd.append("jobId", params.id);
    fd.append("coverLetter", letter);
    if (resume) fd.append("resume", resume);

    const res = await fetch(`${API}/applications`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: fd
    });

    const data = await res.json();
    setMessage(data.message || "Done");
  }

  if (!job) return <main className="container"><p>Loading job...</p></main>;

  return (
    <main className="container">
      <h1>{job.title}</h1>
      <h2>{job.company}</h2>
      <p>{job.location} · {job.job_type} · {job.salary || "Salary not specified"}</p>
      <hr />
      <h3>Description</h3>
      <p>{job.description}</p>
      <h3>Skills</h3>
      <p>{job.skills}</p>

      <form className="form card" onSubmit={apply}>
        <h2>Apply for this job</h2>
        <input
          type="file"
          accept=".pdf,.doc,.docx"
          onChange={e => setResume(e.target.files[0])}
        />
        <textarea
          rows={6}
          placeholder="Cover letter"
          value={letter}
          onChange={e => setLetter(e.target.value)}
        />
        <button className="button">Submit Application</button>
        <p>{message}</p>
      </form>
    </main>
  );
}
