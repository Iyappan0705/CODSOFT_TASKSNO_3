"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

export default function Register() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "", email: "", password: "", role: "candidate"
  });
  const [message, setMessage] = useState("");

  async function submit(e) {
    e.preventDefault();

    const res = await fetch(`${API}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });

    const data = await res.json();
    setMessage(data.message || "");

    if (res.ok) {
      setTimeout(() => router.push("/login"), 700);
    }
  }

  return (
    <main className="authPage">
      <form className="form card" onSubmit={submit}>
        <h1>Create Account</h1>
        <input
          placeholder="Full name"
          required
          value={form.name}
          onChange={e => setForm({ ...form, name: e.target.value })}
        />
        <input
          type="email"
          placeholder="Email"
          required
          value={form.email}
          onChange={e => setForm({ ...form, email: e.target.value })}
        />
        <input
          type="password"
          placeholder="Password (6+ characters)"
          minLength={6}
          required
          value={form.password}
          onChange={e => setForm({ ...form, password: e.target.value })}
        />
        <select
          value={form.role}
          onChange={e => setForm({ ...form, role: e.target.value })}
        >
          <option value="candidate">Job Seeker / Candidate</option>
          <option value="recruiter">Recruiter</option>
        </select>
        <button className="button">Register</button>
        <p>{message}</p>
        <Link href="/login">Already have an account?</Link>
      </form>
    </main>
  );
}
