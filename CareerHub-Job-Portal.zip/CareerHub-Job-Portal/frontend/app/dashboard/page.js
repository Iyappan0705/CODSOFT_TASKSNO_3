"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [items, setItems] = useState([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("user");
    const token = localStorage.getItem("token");

    if (!saved || !token) {
      window.location.href = "/login";
      return;
    }

    const u = JSON.parse(saved);
    setUser(u);

    const endpoint = u.role === "candidate"
      ? "/applications/mine"
      : "/applications/recruiter";

    fetch(`${API}${endpoint}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(r => r.json())
      .then(data => setItems(Array.isArray(data) ? data : []))
      .catch(() => setMessage("Could not load dashboard"));
  }, []);

  function logout() {
    localStorage.clear();
    window.location.href = "/";
  }

  async function updateStatus(id, status) {
    const token = localStorage.getItem("token");
    const res = await fetch(`${API}/applications/${id}/status`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ status })
    });

    if (res.ok) {
      setItems(items.map(x => x.id === id ? { ...x, status } : x));
    }
  }

  if (!user) return <main className="container"><p>Loading...</p></main>;

  return (
    <main>
      <nav className="nav">
        <Link href="/" className="brand">CareerHub</Link>
        <div>
          {user.role === "recruiter" && <Link href="/post-job" className="navLink">Post Job</Link>}
          <button onClick={logout} className="button small">Logout</button>
        </div>
      </nav>

      <section className="container">
        <h1>{user.name}'s Dashboard</h1>
        <p>{user.email} · {user.role}</p>
        <p>{message}</p>

        {user.role === "candidate" ? (
          <>
            <h2>My Applications</h2>
            <div className="grid">
              {items.map(a => (
                <article className="card" key={a.id}>
                  <h3>{a.title}</h3>
                  <p>{a.company} · {a.location}</p>
                  <p>Status: <b>{a.status}</b></p>
                  <p>Applied: {new Date(a.applied_at).toLocaleDateString()}</p>
                </article>
              ))}
            </div>
          </>
        ) : (
          <>
            <h2>Applicants</h2>
            <div className="grid">
              {items.map(a => (
                <article className="card" key={a.id}>
                  <h3>{a.candidate_name}</h3>
                  <p>{a.candidate_email}</p>
                  <p>Job: <b>{a.title}</b></p>
                  <p>Status: <b>{a.status}</b></p>
                  <select
                    value={a.status}
                    onChange={e => updateStatus(a.id, e.target.value)}
                  >
                    <option>Applied</option>
                    <option>Shortlisted</option>
                    <option>Rejected</option>
                    <option>Selected</option>
                  </select>
                </article>
              ))}
            </div>
          </>
        )}

        {!items.length && <p>No records yet.</p>}
      </section>
    </main>
  );
}
