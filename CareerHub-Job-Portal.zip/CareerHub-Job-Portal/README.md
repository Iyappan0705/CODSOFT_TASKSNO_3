# CareerHub – Job Portal

A college-project full-stack job portal with:
- Candidate registration/login
- Recruiter registration/login
- Job search
- Recruiter job posting
- Candidate job applications
- Application status tracking
- Resume upload
- Recruiter applicant management

## Stack
Frontend: Next.js
Backend: Node.js + Express
Database: PostgreSQL
Authentication: JWT + bcrypt
File upload: Multer (local `uploads/` folder for the demo)

## Requirements
- Node.js 20+ (Node 24 is fine)
- npm
- PostgreSQL

## 1. Create the database

Open PostgreSQL / pgAdmin and create a database:

    CREATE DATABASE careerhub;

Then open the `database/schema.sql` file and run it inside the `careerhub` database.

## 2. Start backend

Open CMD:

    cd CareerHub-Job-Portal\backend
    npm install

Create `.env` from `.env.example`:

    PORT=5000
    DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/careerhub
    JWT_SECRET=careerhub_demo_secret_change_this

Then:

    npm run dev

Backend:
    http://localhost:5000

## 3. Start frontend

Open a second CMD:

    cd CareerHub-Job-Portal\frontend
    npm install

Create `.env.local`:

    NEXT_PUBLIC_API_URL=http://localhost:5000/api

Then:

    npm run dev

Frontend:
    http://localhost:3000

## Demo flow

1. Register a Recruiter account.
2. Login as recruiter.
3. Post a job.
4. Logout.
5. Register a Candidate account.
6. Login as candidate.
7. Search jobs and apply.
8. Open Dashboard to see the application.
9. Login as recruiter again and update the applicant status.

## Important
This version stores resumes in the backend `uploads/` folder to make the college demo easy to run.
For a production deployment, replace local storage with Cloud Storage/S3/Cloudinary and use secure httpOnly cookies.
